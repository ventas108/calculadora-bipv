"""
Módulo de producción anual BIPV — IEC 61724.

Simula la energía hora a hora aplicando:
  1. Motor eléctrico por módulo -- SDM PVsyst v6 vectorizado (pvlib) para la
     mayoría de tecnologías; power-rating model JRC/Huld (Huld et al. 2011)
     para CdTe -- ver nota "Motor CdTe" abajo.
  2. Factor de pérdidas ópticas/eléctricas de la cascada Mismatch
  3. Temperatura de celda NOCT hora a hora
  4. Curva de eficiencia del inversor

Motor CdTe (2-sep-2026, ver DIAGNOSTICO_JRC_HULD_PRIMARIO_CDTE.md): para
paneles CdTe, este módulo usa el power-rating model JRC/Huld como motor
PRIMARIO de energía, no el SDM. Decisión basada en evidencia real: comparado
contra una corrida real de PVsyst 8.1.5 (panel ASP-ST1-T40, fachada vertical,
Teusaquillo), el patrón mensual de PR de JRC/Huld correlaciona con el real
(r=0.545, RMSE=13.2pts) mientras el SDM no correlaciona en absoluto
(r=-0.142, RMSE=16.2pts) -- el SDM con Rsh exponencial produce una "joroba"
de eficiencia por encima del 100% entre G=100-300 W/m² que ni PVsyst real ni
el modelo empírico JRC/Huld (ajustado contra mediciones reales de módulos
CdTe en el ESTI europeo) reproducen. Esto SOLO cambia el cálculo de energía
de este módulo -- Motor IV (produccion_iv.py), mismatch/bypass
(mismatch_bypass.py) y MPPT compartido (mppt_combinado.py) siguen en el SDM
exclusivamente, porque necesitan la curva I-V completa (Vmp/Voc/Isc) que
JRC/Huld no calcula (JRC/Huld solo predice Pmax).

Métricas de salida (IEC 61724):
  Y_f  — Final yield    (kWh/kWp)
  Y_r  — Reference yield (kWh/m² / kW/m² = h)
  Y_a  — Array yield    (kWh/kWp)
  PR   — Performance Ratio = Y_f / Y_r
  CF   — Capacity Factor (%)
"""

import numpy as np
import pandas as pd

from calculos.modelo_iv import calcular_pmax_vectorizado
from calculos.modelo_jrc_huld import clasificar_tecnologia_jrc, potencia_jrc
from calculos.temperatura import temperatura_celda_noct
from calculos.dimensionamiento import calcular_vmp_string
from calculos.agregador_anual import (
    agregar_anual_8760_poa,
    validar_entradas_horarias_8760,
)

# ── Constantes físicas (mismas que modelo_iv.py) ──────────────────────────────
K_BOLTZMANN = 1.380649e-23
Q_ELECTRON  = 1.602176634e-19
T_REF_K     = 298.15
G_REF       = 1000.0


# ── Parámetros SDM mínimos requeridos para el modelo De Soto completo ─────────
_SDM_PARAMS_REQUERIDOS = ("I_L_ref", "I_o_ref", "R_s", "R_sh_ref", "a_ref")


def panel_tiene_sdm_completo(panel: dict) -> bool:
    """Retorna True si el panel tiene todos los parámetros SDM para De Soto 2006."""
    return all(
        panel.get(p) is not None and float(panel.get(p)) != 0.0
        for p in _SDM_PARAMS_REQUERIDOS
    )


def determinar_source_mode(panel: dict, produccion_modo_iv: bool) -> str:
    """
    Método físico EFECTIVO que produce la energía oficial de esta corrida
    (produccion-codespec Fase 1, campo `source_mode` de
    produccion_run_signature_v1) -- mismo orden de prioridad que ya aplica
    esta página al elegir `res` entre res_iv/res_base:

      1. produccion_modo_iv=True  → "motor_iv"   (curva I-V real, opt-in,
         tiene prioridad incluso para CdTe -- reemplaza tanto al SDM como a
         JRC/Huld cuando el usuario lo activa explícitamente).
      2. Panel CdTe                → "jrc_huld"   (motor PRIMARIO de energía
         para CdTe, ver nota "Motor CdTe" en el docstring del módulo).
      3. Panel con SDM completo    → "sdm_pvsyst" (De Soto/PVsyst v6).
      4. Cualquier otro caso       → "lineal"     (fallback simplificado).
    """
    if produccion_modo_iv:
        return "motor_iv"
    if clasificar_tecnologia_jrc(panel.get("tecnologia")) == "CdTe":
        return "jrc_huld"
    if panel_tiene_sdm_completo(panel):
        return "sdm_pvsyst"
    return "lineal"


def _calcular_pmax_vectorizado(
    G: np.ndarray,
    T_cel: np.ndarray,
    panel: dict,
) -> np.ndarray:
    """
    Calcula Pmax (W) por módulo hora a hora.

    Para CdTe usa el power-rating model JRC/Huld como motor PRIMARIO (ver
    nota "Motor CdTe" en el docstring del módulo y
    DIAGNOSTICO_JRC_HULD_PRIMARIO_CDTE.md) -- reemplaza al SDM SOLO aquí
    (cálculo de energía), nunca en Motor IV/mismatch/MPPT compartido, que
    necesitan la curva I-V completa. Para el resto de tecnologías usa el SDM
    PVsyst v6 vectorizado (pvlib), con el modelo Rsh exponencial CdTe/CIGS
    (Mermoud 2005) donde aplica.

    G     : irradiancia efectiva en el plano (W/m²) — array 1D
    T_cel : temperatura de celda (°C) — array 1D
    panel : dict con parámetros del catálogo

    Retorna: array 1D de Pmax (W) por módulo
    """
    # ── CdTe: JRC/Huld primario (no requiere parámetros SDM, solo Pmax_stc) ──
    if clasificar_tecnologia_jrc(panel.get("tecnologia")) == "CdTe":
        pmax_stc = float(panel.get("Pmax_stc") or 0.0)
        if pmax_stc > 0:
            pmax = potencia_jrc(G, T_cel, pmax_stc, tecnologia="CdTe")
            pmax[G < 5.0] = 0.0
            return pmax
        # Pmax_stc ausente/0: cae al fallback lineal genérico de abajo (mismo
        # comportamiento que un panel sin SDM completo).

    # ── Fallback para paneles sin parámetros SDM completos ───────────────────
    # (paneles del catálogo Excel que no tienen a_ref, I_L_ref, etc.)
    if not panel_tiene_sdm_completo(panel):
        # panel.get("Tk_gamma", -0.45) NO cubre el caso real: en el catálogo
        # Excel la clave existe pero vale None (no está ausente) -- .get()
        # con default solo aplica si la clave falta, así que quedaba
        # float(None) y TypeError. Bug preexistente, alcanzable recién ahora
        # que variable_panel() expone el catálogo Excel completo (27-ago-2026)
        # -- encontrado corriendo comparar_paneles() sobre los 65 paneles
        # reales. Mismo idiom `or` que ya usan NOCT (línea ~171) y Tk_alfa
        # (línea ~86) en este archivo para el mismo problema.
        gamma = float(panel.get("Tk_gamma") or -0.45) / 100.0   # %/°C → 1/°C
        pmax_stc = float(panel.get("Pmax_stc") or 0)
        pmax = pmax_stc * np.where(G > 5.0, G / 1000.0, 0.0) * (1.0 + gamma * (T_cel - 25.0))
        pmax = np.maximum(pmax, 0.0)
        return pmax

    # Motor SDM centralizado en calculos.modelo_iv.calcular_pmax_vectorizado()
    # (modelo PVsyst v6, Sauer/Roessler/Hansen 2015 -- migrado desde De Soto
    # 2006 el 2-sep-2026, ver DIAGNOSTICO_MOTOR_PVSYST.md; incluye el término
    # de recombinación PVsyst/Merten 1998 para CdTe con d2mutau calibrado,
    # ver DIAGNOSTICO_RECOMBINACION_CDTE.md). Antes cada una de las 5
    # implementaciones del SDM reimplementaba esta llamada por su cuenta (ver
    # test_consistencia_sdm_entre_modulos.py, que existe precisamente para
    # atrapar el riesgo de que una copia se actualice y las otras no) -- se
    # centraliza aquí para eliminar esa clase de bug.
    pmax = calcular_pmax_vectorizado(G, T_cel, panel)
    pmax[G < 5.0] = 0.0     # sin producción nocturna / irradiancia mínima
    pmax[pmax < 0] = 0.0    # seguridad numérica
    return pmax


def simular_produccion_anual(
    tmy: pd.DataFrame,
    poa_base: pd.DataFrame,
    panel: dict,
    N_paneles: int,
    eta_inversor: float,
    factor_pr_mismatch: float,
    P_dc_stc_kW: float | None = None,
    k_bipv: float = 1.0,
    P_ac_nom_W: float | None = None,
    poa_bruta_kWh_m2: float | None = None,
    factor_espectral: pd.Series | np.ndarray | None = None,
    pct_mismatch_fab: float | None = None,
    resistencia_dc_ohm: float | None = None,
    pct_cableado_dc: float | None = None,
    resistencia_ac_ohm: float | None = None,
    pct_cableado_ac: float | None = None,
    N_serie: int | None = None,
    tension_red_V: float | None = None,
) -> dict:
    """
    Simulación de producción anual hora a hora — IEC 61724.

    Parámetros
    ----------
    tmy                 : DataFrame TMY con columna 'T2m' (°C)
    poa_base            : DataFrame POA bruta con columna 'poa_global' (W/m²)
    panel               : dict del catálogo MODULOS_BIPV
    N_paneles           : número de módulos del sistema
    eta_inversor        : eficiencia del inversor (0.90–0.99)
    factor_pr_mismatch  : factor de pérdidas cascada (0–1)
                          = poa_efectiva / poa_bruta  (de página Mismatch)
    P_dc_stc_kW         : potencia pico instalada kWp; si None → N_paneles × Pmax_stc
    k_bipv              : factor de confinamiento térmico BIPV (IEA-PVPS T15).
                          1.0 = ventilado libre, 1.3 = fachada confinada (defecto BIPV),
                          1.5 = sellado total. Aumenta T_celda y reduce eficiencia.
    P_ac_nom_W          : potencia AC nominal del inversor (W) -- tope físico real de
                          salida (PVsyst la llama "Pnom" y SIEMPRE recorta con ella).
                          Si None (default, retrocompatible), NO se aplica ningún tope
                          -- comportamiento histórico de esta función. Bug real
                          encontrado el 29-ago-2026: sin este parámetro, P_ac = P_dc ×
                          eta_inversor sin límite, así que un array DC más grande que
                          el inversor (relación DC/AC > 1 -- el diseño ESTÁNDAR de la
                          industria, típicamente 1.1-1.3, no un caso raro) hacía que la
                          app sobreestimara producción -- verificado con un caso
                          sintético DC/AC=1.3: +10.8% en un día despejado, 5 de 24 h
                          recortadas. Nunca se detectó en los proyectos ya validados
                          contra PVsyst esta sesión (Urabá 0.88, Teusaquillo 0.54)
                          porque AMBOS tienen relación DC/AC < 1 -- el recorte nunca se
                          disparaba en esos casos, no porque no hiciera falta.
    poa_bruta_kWh_m2    : POA bruta REAL del sitio (kWh/m²/año), ANTES de cualquier
                          corrección óptica (IAM/soiling del Motor Óptico) -- típicamente
                          `poa_anual_kWh_m2` de ☀️ Recurso Solar. IEC 61724 define el
                          Reference Yield (Y_r) respecto a la irradiancia incidente en el
                          plano SIN corregir, no respecto a la POA ya optimizada.
                          Si None (default, retrocompatible): Y_r se calcula sumando
                          `poa_base` (comportamiento histórico) -- correcto cuando
                          `poa_base` YA es la bruta real (sin Motor Óptico activo), pero
                          bug real encontrado el 6-sep-2026 auditando este módulo: cuando
                          `poa_base` viene post-IAM+soiling (Motor Óptico activo, que pasa
                          `poa_sin_termico_df` aquí), Y_r quedaba "adelgazado" por esas
                          pérdidas en vez de contarlas como pérdida real -- el PR mostrado
                          salía más alto que un PR IEC 61724 estricto. La tabla de balance
                          `perdidas_desglosadas()` nunca tuvo este bug (ya recibía la
                          bruta real por su propio parámetro `poa_bruta_kWh_m2`) -- este
                          parámetro homónimo alinea `simular_produccion_anual()` con el
                          mismo criterio. Ningún kWh ni cifra financiera cambia con esto
                          -- solo el % de PR reportado cuando Motor Óptico está activo.
    factor_espectral    : factor multiplicativo horario (Series/array, mismo índice que
                          `tmy`) de corrección espectral -- ver `calculos.
                          correccion_espectral.calcular_factor_espectral_cdte()`.
                          Se aplica SOLO si el panel clasifica como tecnología CdTe
                          (`modelo_jrc_huld.clasificar_tecnologia_jrc`); para cualquier
                          otra tecnología se ignora por completo aunque se pase (defensa
                          ante mal uso -- el factor First Solar 'cdte' no es válido para
                          silicio cristalino ni CIS). Se aplica SOLO al cálculo eléctrico
                          (Pmax) -- NUNCA a `G_eff`/`H_ef`/`T_cel`: el efecto espectral
                          es una limitación de cuánta corriente puede extraer la CELDA
                          del espectro real, no un cambio en la irradiancia física que
                          llega al plano (esa irradiancia sigue calentando el módulo y
                          contando como "POA efectiva" igual). None (default) = sin
                          corrección, retrocompatible.
    pct_mismatch_fab    : % de pérdida por tolerancia de fabricación / "calidad de
                          módulo" (binning) -- 7-sep-2026, ver
                          DIAGNOSTICO_PERDIDA_OHMICA_BINNING.md. Antes se aplicaba
                          (con otro nombre, "pct_mismatch_fab" del slider de Página
                          5 Mismatch) como reductor de G_eff ANTES del modelo
                          eléctrico -- físicamente impreciso (es una pérdida
                          eléctrica post-conversión, no una reducción de
                          irradiancia) y quedaba escondido dentro de "② Efecto
                          SDM" del Loss Diagram, sin fila propia. Ahora se aplica
                          aquí, como multiplicador directo sobre Pmax (no varía
                          hora a hora -- es tolerancia de fábrica, no un efecto
                          eléctrico dependiente de corriente). None (default) =
                          sin pérdida, retrocompatible.
    resistencia_dc_ohm  : resistencia DC efectiva (Ω) de todo el tramo de
                          cableado del array al inversor -- ver calculos.
                          diagrama_unifilar.calcular_perdida_ohmica()
                          ("resistencia_dc_efectiva_ohm", ya agregada de todos
                          los tramos/superficies). Si se pasa, la pérdida óhmica
                          se calcula HORA A HORA con la corriente real
                          I(t)=P_dc(t)/V_string(t) (más preciso que el % fijo
                          de PVsyst, que sobreestima la pérdida en horas de baja
                          irradiancia) -- requiere también N_serie. Tiene
                          prioridad sobre pct_cableado_dc; nunca se aplican
                          ambos a la vez.
    pct_cableado_dc      : % fijo de pérdida óhmica DC -- modo manual, usado
                          SOLO si resistencia_dc_ohm es None (no hay datos
                          reales de cableado del proyecto todavía). None
                          (default) = sin pérdida, retrocompatible.
    resistencia_ac_ohm  : igual que resistencia_dc_ohm pero para el tramo
                          inversor→punto de conexión -- requiere también
                          tension_red_V. Se aplica DESPUÉS del recorte del
                          inversor (ahí ya no hay no-linealidad aguas abajo).
    pct_cableado_ac      : % fijo de pérdida óhmica AC -- modo manual, usado
                          SOLO si resistencia_ac_ohm es None. None (default) =
                          sin pérdida (a diferencia de pct_cableado_dc, esta
                          pérdida no tenía NINGUNA representación antes de
                          7-sep-2026 -- nunca inventar un valor por defecto
                          distinto de cero para algo que antes no existía).
    N_serie              : paneles en serie por string -- necesario SOLO para
                          calcular V_string(t) en el modo DC calculado. Si es
                          None, resistencia_dc_ohm se ignora (queda como si no
                          se hubiera pasado) en vez de reventar.
    tension_red_V        : tensión de red (V) -- necesaria SOLO para el modo AC
                          calculado. Si es None, resistencia_ac_ohm se ignora.

    Retorna dict
    ────────────
    E_dc_anual_kWh       : energía DC anual (kWh)
    E_ac_anual_kWh       : energía AC anual (kWh) -- YA recortada si P_ac_nom_W se pasó
    P_stc_kW             : potencia instalada (kWp)
    Y_f                  : Final yield (kWh/kWp)
    Y_r                  : Reference yield (h = kWh/m²) -- ver poa_bruta_kWh_m2 arriba
    Y_r_es_bruta_real    : True si Y_r usó la POA bruta real pasada (poa_bruta_kWh_m2);
                          False si cayó al fallback histórico (suma de poa_base) --
                          explícito para que quien consuma el resultado sepa cuál
                          definición de PR está viendo, sin tener que inspeccionar código.
    Y_a                  : Array yield (kWh/kWp)
    PR                   : Performance Ratio IEC 61724
    CF_pct               : Capacity Factor (%)
    perdida_temp_kWh     : energía perdida por temperatura
    perdida_inv_kWh      : energía perdida en inversor por eficiencia (SIN recorte)
    perdida_clipping_kWh : energía perdida por recorte al Pnom del inversor (0 si no
                          se pasó P_ac_nom_W, o si el array nunca superó el inversor)
    horas_con_clipping   : nº de horas del año con recorte activo (0-8760)
    factor_espectral_aplicado  : True si el panel es CdTe Y se pasó factor_espectral
                          -- explícito para auditar de un vistazo si esta corrida
                          incluyó la corrección espectral o no.
    factor_espectral_promedio : promedio del factor en horas de sol (None si no se
                          aplicó) -- >1.0 = ganancia neta por espectro más azul de lo
                          estándar en el sitio; <1.0 = pérdida neta.
    df_horario           : DataFrame horario (G_eff, factor_espectral [1.0 si no se
                          aplicó], T_cel, Pmax, P_dc, P_ac, clipping_kW)
    df_mensual           : DataFrame mensual con E_dc, E_ac, kWh/kWp
    """
    if P_dc_stc_kW is None:
        P_dc_stc_kW = round(panel.get("Pmax_stc", 60) * N_paneles / 1000, 3)

    # ── Validar año TMY completo antes de simular ─────────────────────────────
    # Nunca usar intersection(): descartaría horas silenciosamente y después
    # las métricas anuales aparentarían cubrir 8760 h aunque no lo hagan.
    validar_entradas_horarias_8760(tmy, poa_base)
    idx   = tmy.index
    G_raw = poa_base.loc[idx, "poa_global"].values.astype(float)
    T_amb = tmy.loc[idx, "T2m"].values.astype(float)

    # ── Irradiancia efectiva (cascada mismatch aplicada) ──────────────────────
    G_eff = np.clip(G_raw * factor_pr_mismatch, 0, None)

    # ── Temperatura de celda hora a hora (modelo NOCT + k_BIPV confinamiento) ──
    try:
        NOCT = float(panel.get("NOCT") or 45.0)
        if not (20.0 < NOCT < 100.0):
            NOCT = 45.0
    except (TypeError, ValueError):
        NOCT = 45.0
    # k_bipv eleva la temperatura de celda en fachadas con ventilación restringida.
    # IEA-PVPS T15: 1.0=ventilado libre, 1.3=confinado típico, 1.5=sellado total.
    T_cel = temperatura_celda_noct(G_eff, T_amb, NOCT=NOCT, k_bipv=k_bipv)

    # ── Corrección espectral CdTe (6-sep-2026, ver calculos.correccion_espectral) ──
    # Se aplica SOLO a la irradiancia que ve el modelo eléctrico (G_para_potencia),
    # NUNCA a G_eff -- el efecto espectral es una limitación de cuánta corriente
    # extrae la CELDA del espectro real, no un cambio en la irradiancia física
    # (esa irradiancia real sigue siendo la que calienta el módulo y la que se
    # reporta como POA efectiva/H_ef). Defensa: se ignora por completo si el
    # panel no es CdTe, aunque el caller pase un factor (el modelo First Solar
    # 'cdte' no es válido para otras tecnologías).
    factor_espectral_aplicado = False
    factor_espectral_promedio = None
    G_para_potencia = G_eff
    if factor_espectral is not None and clasificar_tecnologia_jrc(panel.get("tecnologia")) == "CdTe":
        fe = np.asarray(factor_espectral, dtype=float)
        if fe.shape == G_eff.shape:
            G_para_potencia = G_eff * fe
            factor_espectral_aplicado = True
            _mask_dia = G_eff > 5.0
            factor_espectral_promedio = (
                round(float(fe[_mask_dia].mean()), 4) if _mask_dia.any() else 1.0
            )
        # Forma distinta (ej. índice desalineado) -- se ignora en vez de
        # reventar o aplicar mal alineado; ningún caller actual dispara esto,
        # es una defensa ante uso futuro incorrecto.

    # ── SDM vectorizado — Pmax por módulo ─────────────────────────────────────
    pmax_mod = _calcular_pmax_vectorizado(G_para_potencia, T_cel, panel)

    # ── Pérdida por temperatura (referencia: Pmax a T=25°C con mismo G_eff) ───
    T_ref_arr = np.full_like(T_cel, 25.0)
    pmax_stc_g = _calcular_pmax_vectorizado(G_para_potencia, T_ref_arr, panel)
    perdida_temp_por_modulo = np.maximum(pmax_stc_g - pmax_mod, 0.0)

    # ── Mismatch fabricación + pérdida óhmica DC (7-sep-2026) ─────────────────
    # Se aplican DESPUÉS de perdida_temp_por_modulo (que debe medir solo el
    # efecto SDM puro, sin mezclarse con estos 2) -- ver docstrings arriba.
    # pmax_stc_g NO se toca: sigue siendo la referencia T=25°C pura para la
    # fila ②a/②b del Loss Diagram.
    E_dc_antes_binning_ohmico_kWh = float(pmax_mod.sum()) * N_paneles / 1000.0

    pct_mismatch_fab_aplicado = None
    if pct_mismatch_fab:
        pmax_mod = pmax_mod * (1.0 - pct_mismatch_fab / 100.0)
        pct_mismatch_fab_aplicado = pct_mismatch_fab
    E_dc_despues_mismatch_kWh = float(pmax_mod.sum()) * N_paneles / 1000.0

    perdida_ohmica_dc_modo = None
    perdida_ohmica_dc_por_hora_W = np.zeros_like(pmax_mod)
    if resistencia_dc_ohm is not None and resistencia_dc_ohm > 0 and N_serie:
        Vmp_mod_t = calcular_vmp_string(
            1, float(panel.get("Vmp_stc") or 0.0), float(panel.get("Tk_beta") or 0.0), T_cel
        )
        V_string_t = Vmp_mod_t * N_serie
        P_dc_bruta_W = pmax_mod * N_paneles
        I_total_A = np.divide(
            P_dc_bruta_W, V_string_t,
            out=np.zeros_like(P_dc_bruta_W), where=(V_string_t > 1.0),
        )
        perdida_ohmica_dc_por_hora_W = (I_total_A ** 2) * resistencia_dc_ohm
        pmax_mod = np.maximum(
            pmax_mod - perdida_ohmica_dc_por_hora_W / N_paneles, 0.0
        )
        perdida_ohmica_dc_modo = "calculado"
    elif pct_cableado_dc:
        pmax_mod = pmax_mod * (1.0 - pct_cableado_dc / 100.0)
        perdida_ohmica_dc_modo = "manual"
    E_dc_despues_ohmico_dc_kWh = float(pmax_mod.sum()) * N_paneles / 1000.0

    perdida_mismatch_fab_kWh = round(E_dc_antes_binning_ohmico_kWh - E_dc_despues_mismatch_kWh, 0)
    perdida_ohmica_dc_kWh    = round(E_dc_despues_mismatch_kWh - E_dc_despues_ohmico_dc_kWh, 0)

    # ── Escalar al sistema ─────────────────────────────────────────────────────
    P_dc_W       = pmax_mod * N_paneles
    P_ac_sin_recorte_W = P_dc_W * eta_inversor
    # Recorte al Pnom del inversor (PVsyst: siempre activo) -- ver docstring
    # "P_ac_nom_W" de esta función para el hallazgo real que motivó esto.
    if P_ac_nom_W is not None and P_ac_nom_W > 0:
        P_ac_W = np.minimum(P_ac_sin_recorte_W, P_ac_nom_W)
    else:
        P_ac_W = P_ac_sin_recorte_W
    clipping_W = P_ac_sin_recorte_W - P_ac_W   # siempre >= 0

    # ── Pérdida óhmica AC (7-sep-2026) ─────────────────────────────────────────
    # Después del recorte -- ahí ya no hay no-linealidad aguas abajo (el
    # recorte es intrínseco al inversor, no depende de lo que pase con el
    # cable después de sus bornes de salida).
    E_ac_antes_ohmico_ac_kWh = float(P_ac_W.sum()) / 1000.0
    perdida_ohmica_ac_modo = None
    perdida_ohmica_ac_por_hora_W = np.zeros_like(P_ac_W)
    if resistencia_ac_ohm is not None and resistencia_ac_ohm > 0 and tension_red_V:
        # Trifásica, factor de potencia = 1 asumido (no se modela cosφ) --
        # misma simplificación que ya usa corriente_diseno_ac() en todo el
        # resto de la app para dimensionar breakers/protecciones.
        I_ac_A = P_ac_W / (np.sqrt(3.0) * tension_red_V)
        perdida_ohmica_ac_por_hora_W = (I_ac_A ** 2) * resistencia_ac_ohm
        P_ac_W = np.maximum(P_ac_W - perdida_ohmica_ac_por_hora_W, 0.0)
        perdida_ohmica_ac_modo = "calculado"
    elif pct_cableado_ac:
        _perdida_pct_ac_W = P_ac_W * (pct_cableado_ac / 100.0)
        perdida_ohmica_ac_por_hora_W = _perdida_pct_ac_W
        P_ac_W = P_ac_W - _perdida_pct_ac_W
        perdida_ohmica_ac_modo = "manual"
    perdida_ohmica_ac_kWh = round(E_ac_antes_ohmico_ac_kWh - float(P_ac_W.sum()) / 1000.0, 0)

    # ── Energías anuales (Wh → kWh) ───────────────────────────────────────────
    E_dc_anual  = float(P_dc_W.sum()) / 1000.0
    E_ac_anual  = float(P_ac_W.sum()) / 1000.0
    E_ac_sin_recorte_anual = float(P_ac_sin_recorte_W.sum()) / 1000.0
    perdida_temp_kWh = float(perdida_temp_por_modulo.sum()) * N_paneles / 1000.0
    # Pérdida de eficiencia PURA (sin recorte) -- separada del recorte para que
    # cada pérdida se pueda reportar por su causa real, como hace PVsyst.
    perdida_inv_kWh      = E_dc_anual - E_ac_sin_recorte_anual
    # E_ac_antes_ohmico_ac_kWh (post-recorte, PRE pérdida óhmica AC) -- no
    # E_ac_anual, que ya incluye la pérdida óhmica AC nueva -- si no, el
    # recorte del inversor "se comería" también la pérdida de cableado AC.
    perdida_clipping_kWh = E_ac_sin_recorte_anual - E_ac_antes_ohmico_ac_kWh
    horas_con_clipping   = int(np.sum(clipping_W > 1e-6))

    # ── Métricas IEC 61724 ────────────────────────────────────────────────────
    # Y_r (Reference Yield) debe referenciarse a la POA bruta REAL (ver
    # docstring "poa_bruta_kWh_m2" arriba) -- si no se pasa, cae al histórico
    # sum(poa_base), correcto solo cuando poa_base YA es la bruta real.
    Y_r_es_bruta_real = poa_bruta_kWh_m2 is not None
    H_i  = float(poa_bruta_kWh_m2) if Y_r_es_bruta_real else float(G_raw.sum()) / 1000.0
    H_ef = float(G_eff.sum()) / 1000.0          # POA efectiva kWh/m² (post-mismatch)
    Y_r  = H_i                                   # Reference yield [h] = H_t / G_STC (IEC 61724)
    # NOTA: Y_r usa POA bruta (H_i), no H_ef, para que el PR incluya las pérdidas
    # de mismatch como una pérdida real (PR más conservador y correcto según IEC 61724).
    Y_a  = E_dc_anual  / P_dc_stc_kW if P_dc_stc_kW > 0 else 0.0   # Array yield
    Y_f  = E_ac_anual  / P_dc_stc_kW if P_dc_stc_kW > 0 else 0.0   # Final yield
    PR   = Y_f / Y_r   if Y_r > 0    else 0.0   # Performance Ratio
    CF   = E_ac_anual  / (P_dc_stc_kW * 8760) if P_dc_stc_kW > 0 else 0.0

    # ── DataFrame horario ─────────────────────────────────────────────────────
    df_h = pd.DataFrame({
        "G_eff_Wm2":    G_eff,
        "factor_espectral": (
            G_para_potencia / np.where(G_eff > 0, G_eff, 1.0)
            if factor_espectral_aplicado else np.ones_like(G_eff)
        ),
        "T_cel_C":      T_cel,
        "Pmax_mod_W":   pmax_mod,
        "P_dc_kW":      P_dc_W  / 1000.0,
        "P_ac_kW":      P_ac_W  / 1000.0,
        "perdida_T_kW": perdida_temp_por_modulo * N_paneles / 1000.0,
        "clipping_kW":  clipping_W / 1000.0,
        "perdida_ohmica_dc_W": perdida_ohmica_dc_por_hora_W,
        "perdida_ohmica_ac_W": perdida_ohmica_ac_por_hora_W,
    }, index=idx)

    # ── Contrato anual oficial: suma directa de las 8760 horas ───────────────
    # Se conservan las claves E_* históricas para Baterías, Financiero y Reporte.
    anual_8760 = agregar_anual_8760_poa(
        resultado_horario=df_h,
        poa_horaria=poa_base,
        columnas_energia=("P_dc_kW", "P_ac_kW", "perdida_T_kW", "clipping_kW"),
    )["annual_8760"]

    # ── DataFrame mensual ─────────────────────────────────────────────────────
    meses_es = {1:"Ene",2:"Feb",3:"Mar",4:"Abr",5:"May",6:"Jun",
                7:"Jul",8:"Ago",9:"Sep",10:"Oct",11:"Nov",12:"Dic"}
    df_m = (df_h[["P_dc_kW","P_ac_kW","perdida_T_kW","clipping_kW"]]
            .resample("ME").sum()
            .rename(columns={
                "P_dc_kW":      "E_dc (kWh)",
                "P_ac_kW":      "E_ac (kWh)",
                "perdida_T_kW": "Pérdida T° (kWh)",
                "clipping_kW":  "Recorte inversor (kWh)",
            }))
    df_m["Producción (kWh/kWp)"] = df_m["E_ac (kWh)"] / P_dc_stc_kW if P_dc_stc_kW > 0 else 0
    df_m.index = [meses_es[m] for m in df_m.index.month]

    return {
        "E_dc_anual_kWh":         round(E_dc_anual, 0),
        "E_ac_anual_kWh":         round(E_ac_anual, 0),
        "P_stc_kW":               round(P_dc_stc_kW, 3),
        "Y_f":                    round(Y_f, 0),
        "Y_r":                    round(Y_r, 0),
        "Y_r_es_bruta_real":      Y_r_es_bruta_real,
        "Y_a":                    round(Y_a, 0),
        "PR":                     round(PR, 3),
        "CF_pct":                 round(CF * 100, 1),
        "perdida_temp_kWh":       round(perdida_temp_kWh, 0),
        "perdida_inv_kWh":        round(perdida_inv_kWh, 0),
        "perdida_clipping_kWh":   round(perdida_clipping_kWh, 0),
        "horas_con_clipping":     horas_con_clipping,
        "factor_espectral_aplicado":  factor_espectral_aplicado,
        "factor_espectral_promedio":  factor_espectral_promedio,
        "E_ac_sin_recorte_kWh":   round(E_ac_sin_recorte_anual, 0),
        # Mismatch fabricación + pérdida óhmica DC/AC (7-sep-2026) -- ver
        # docstrings de pct_mismatch_fab/resistencia_dc_ohm/resistencia_ac_ohm
        # arriba. E_dc_antes_binning_ohmico_kWh es el punto de referencia que
        # usa perdidas_desglosadas() para las nuevas filas ②c/②d del Loss
        # Diagram -- reconciliación exacta, ningún kWh se pierde ni se inventa.
        "E_dc_antes_binning_ohmico_kWh": round(E_dc_antes_binning_ohmico_kWh, 0),
        "pct_mismatch_fab_aplicado":     pct_mismatch_fab_aplicado,
        "perdida_mismatch_fab_kWh":      perdida_mismatch_fab_kWh,
        "perdida_ohmica_dc_kWh":         perdida_ohmica_dc_kWh,
        "perdida_ohmica_dc_modo":        perdida_ohmica_dc_modo,
        "E_ac_antes_ohmico_ac_kWh":      round(E_ac_antes_ohmico_ac_kWh, 0),
        "perdida_ohmica_ac_kWh":         perdida_ohmica_ac_kWh,
        "perdida_ohmica_ac_modo":        perdida_ohmica_ac_modo,
        # E_dc con la MISMA G_eff real pero T_cel fija en 25°C (STC) para las
        # 8760 h -- ya se calculaba internamente como paso intermedio
        # (pmax_stc_g) para "perdida_temp_kWh", pero nunca se exponía sumado.
        # Permite separar "efecto SDM" en irradiancia vs. temperatura, estilo
        # PVsyst, sin ninguna fórmula física nueva -- 1-sep-2026, ver
        # DIAGNOSTICO_LOSS_DIAGRAM_PVSYST.md.
        "E_dc_a_T25_kWh":         round(float(pmax_stc_g.sum()) * N_paneles / 1000.0, 0),
        "H_i_kWh_m2":             round(H_i, 1),
        "H_ef_kWh_m2":            round(H_ef, 1),
        "df_horario":             df_h,
        "df_mensual":             df_m,
        "annual_8760":            anual_8760,
        "critical_dates":         None,
        "uso_modelo_simplificado": not panel_tiene_sdm_completo(panel),
    }


def perdidas_desglosadas(
    res: dict,
    poa_bruta_kWh_m2: float,
    motor_optico_summary: dict | None = None,
) -> pd.DataFrame:
    """
    Tabla de balance energético IEC 61724 — nombres alineados con el "Loss
    Diagram" oficial de PVsyst (POA → IAM → Soiling → efectiva → STC →
    SDM → inversor → red), para que una corrida manual de PVsyst se pueda
    auditar contra esta tabla fila por fila, no solo comparando el PR final.
    Ver DIAGNOSTICO_LOSS_DIAGRAM_PVSYST.md (1-sep-2026).

    Para climas fríos de alta altitud (Bogotá, Medellín) el SDM puede producir
    MÁS que la referencia STC porque los módulos operan por debajo de 25°C.
    En ese caso el 'delta SDM' es positivo (ganancia, no pérdida).

    motor_optico_summary: el dict que devuelve calculos.motor_optico.cascada_optica()
    (o su copia en session_state["motor_optico_summary"]). Si trae las claves
    IAM/soiling reales, se insertan como filas propias (①a/①b) ANTES de "②
    Efecto SDM" -- cuya referencia entonces pasa a ser la POA post-IAM+soiling
    (no la bruta), para no contar la misma pérdida dos veces. Si no se pasa
    (o el Motor Óptico no corrió), la tabla queda exactamente como antes --
    nunca inventa un desglose que no se calculó de verdad para esta sesión.

    Si `res` trae la clave "E_dc_a_T25_kWh" (calculos.produccion.
    simular_produccion_anual() y calculos.produccion_iv.simular_produccion_iv()
    ya la exponen ambas desde el 1-sep-2026), "② Efecto SDM" además se
    descompone en "②a Pérdida por nivel de irradiancia" y "②b Efecto
    temperatura" -- misma SDM ya validada, corrida una segunda vez con
    T_cel fija en 25°C y la misma G_eff real; los dos deltas suman EXACTO
    al de la fila ②, verificado en tests. Si `res` no trae esa clave
    (resultado de una versión anterior, o un caller propio), la fila ②
    queda combinada como antes -- mismo principio de nunca inventar.

    Mismatch de fabricación / calidad de módulo y pérdida óhmica DC/AC
    (7-sep-2026, antes declaradas explícitamente como NO modeladas): si
    `res` trae "pct_mismatch_fab_aplicado"/"perdida_ohmica_dc_modo"/
    "perdida_ohmica_ac_modo" (simular_produccion_anual()/simular_produccion_iv()
    ya las exponen desde esa fecha), se insertan como filas REALES ②c/②d/④c
    con su Δ kWh efectivo -- ya no son solo informativas. Si `res` no trae
    esas claves (resultado de una versión anterior), "②c Módulo" queda
    exactamente como antes (informativa, PVsyst +0,75% de referencia, sin
    aplicar nada) -- mismo principio de nunca inventar un desglose que no se
    calculó de verdad para esta corrida. Las filas ②/②a/②b usan
    "E_dc_antes_binning_ohmico_kWh" como referencia (no
    "E_dc_anual_kWh", que ahora YA viene neto de estas 2 pérdidas) para que
    el efecto SDM/temperatura no se mezcle con ellas -- mismo principio que
    ya evita el doble conteo entre ①a/①b y ②.
    """
    P_stc  = res["P_stc_kW"]
    ref_dc = P_stc * poa_bruta_kWh_m2   # kWh teóricos a STC (Pmax_nom × POA bruta)
    if ref_dc == 0:
        return pd.DataFrame()
    # Referencia "pura SDM" -- antes de mismatch fabricación / óhmico DC
    # (que ahora ya están restados de E_dc_anual_kWh). Sin estas claves
    # (res de una versión anterior), cae exactamente en E_dc_anual_kWh --
    # ningún cambio de comportamiento para quien no usa la función nueva.
    E_dc_pre_binning = res.get("E_dc_antes_binning_ohmico_kWh", res["E_dc_anual_kWh"])

    filas = [
        {
            "Etapa":     "① E ref  (P_STC × POA bruta)",
            "kWh":       round(ref_dc, 0),
            "Δ kWh":     0,
            "Nota":      "Baseline a condiciones STC · equivalente a \"Global incident in coll. plane\" de PVsyst",
        },
    ]

    # ── ①a/①b — IAM y Soiling (solo si el Motor Óptico corrió de verdad) ──────
    _mo = motor_optico_summary or {}
    _tiene_cascada_optica = all(
        k in _mo for k in ("poa_optica_anual_kWh_m2", "poa_post_soil_anual_kWh_m2",
                            "perdida_iam_kWh_m2", "perdida_soil_kWh_m2")
    )
    if _tiene_cascada_optica:
        ref_post_iam  = P_stc * _mo["poa_optica_anual_kWh_m2"]
        ref_post_soil = P_stc * _mo["poa_post_soil_anual_kWh_m2"]
        filas.append({
            "Etapa":     "①a Pérdida IAM  (ángulo de incidencia)",
            "kWh":       round(ref_post_iam, 0),
            "Δ kWh":     round(-P_stc * _mo["perdida_iam_kWh_m2"], 0),
            "Nota":      f"ASHRAE b₀ · equivalente a \"IAM factor on global\" de PVsyst · factor medio {_mo.get('f_iam_prom', '—')}",
        })
        filas.append({
            "Etapa":     "①b Pérdida soiling  (suciedad)",
            "kWh":       round(ref_post_soil, 0),
            "Δ kWh":     round(-P_stc * _mo["perdida_soil_kWh_m2"], 0),
            "Nota":      f"Calendario Colombia · equivalente a \"Soiling loss factor\" de PVsyst · factor medio {_mo.get('f_soil_prom', '—')}",
        })
        # A partir de aquí, la referencia de "② Efecto SDM" es la POA YA
        # corregida por IAM+soiling -- si se siguiera comparando contra la
        # bruta, esas dos pérdidas se contarían dos veces (una aquí arriba,
        # otra de nuevo escondidas dentro del delta de SDM).
        ref_sdm = ref_post_soil
    else:
        ref_sdm = ref_dc

    delta_sdm = E_dc_pre_binning - ref_sdm              # positivo = ganancia temperatura
    delta_t   = -res["perdida_temp_kWh"]                 # horas T > 25 °C (siempre ≤ 0)
    delta_inv = -res["perdida_inv_kWh"]                  # pérdida inversor (siempre ≤ 0)

    def _signo(v):
        return f"+{v:,.0f}" if v >= 0 else f"{v:,.0f}"

    # ── ②a/②b — irradiancia vs. temperatura, separadas de verdad (1-sep-2026) ──
    # E_dc_a_T25_kWh = misma G_eff real, T_cel fija en 25°C (STC) para las
    # 8760 h -- calculado con el MISMO SDM ya validado, solo una segunda
    # corrida con un insumo distinto (no es una fórmula física nueva). Los 2
    # deltas de abajo suman EXACTO al delta_sdm de la fila ② (verificado en
    # tests) -- es una descomposición, no una estimación aparte.
    E_dc_a_T25 = res.get("E_dc_a_T25_kWh")
    _tiene_split_temp = E_dc_a_T25 is not None

    filas += [
        {
            "Etapa":     "② Efecto SDM  (T° + baja irradiancia)",
            "kWh":       round(E_dc_pre_binning, 0),
            "Δ kWh":     round(delta_sdm, 0),
            "Nota":      ("🟢 Ganancia por T_cel < 25°C (clima frío / alta altitud)"
                          if delta_sdm >= 0
                          else "🔴 Pérdida óptica + temperatura") +
                         (" · ver desglose ②a/②b abajo"
                          if _tiene_split_temp else
                          " · combina \"irradiance level\" + \"temperature\" de PVsyst (no separables sin una segunda corrida SDM)"
                          if _tiene_cascada_optica else ""),
        },
    ]

    if _tiene_split_temp:
        delta_irr  = E_dc_a_T25 - ref_sdm
        delta_temp_neto = E_dc_pre_binning - E_dc_a_T25
        filas += [
            {
                "Etapa":     "②a Pérdida por nivel de irradiancia  (T=25°C fijo)",
                "kWh":       round(E_dc_a_T25, 0),
                "Δ kWh":     round(delta_irr, 0),
                "Nota":      "No linealidad del panel a baja luz, aislada de temperatura · equivalente a \"PV loss due to irradiance level\" de PVsyst",
            },
            {
                "Etapa":     "②b Efecto temperatura  (T real vs. 25°C)",
                "kWh":       round(E_dc_pre_binning, 0),
                "Δ kWh":     round(delta_temp_neto, 0),
                "Nota":      ("🟢 Ganancia neta por T_cel < 25°C (clima frío / alta altitud)"
                              if delta_temp_neto >= 0
                              else "🔴 Pérdida neta por temperatura") +
                             " · equivalente a \"PV loss due to temperature\" de PVsyst",
            },
        ]

    filas += [
        {
            # Fila informativa: SOLO las horas donde T_cel > 25°C (ignora las
            # horas con ganancia por frío) -- distinta de "②b" de arriba, que
            # es el efecto NETO (pérdida y ganancia ya compensadas). Se
            # conserva porque responde una pregunta distinta ("¿cuánto cuestan
            # solo las horas calientes?"), no es un paso acumulado de la
            # cascada -- la kWh muestra E_dc (mismo que fila ②).
            "Etapa":     "   ↳ Solo horas calientes  (T_cel > 25°C, sin compensar por frío)",
            "kWh":       round(E_dc_pre_binning, 0),
            "Δ kWh":     round(delta_t, 0),
            "Nota":      f"Sub-componente de ②  ·  Tk_gamma={res.get('Tk_gamma_pct','—')}%/°C",
        },
    ]

    # ── ②c/②d — Mismatch fabricación + pérdida óhmica DC, REALES (7-sep-2026) ──
    # Si `res` no trae estas claves (versión anterior), ②c queda EXACTAMENTE
    # como antes: informativa, PVsyst +0,75% de referencia, sin aplicar nada.
    #
    # ②c SIEMPRE aparece (real o informativa) -- INDEPENDIENTE de si ②d
    # también aparece. Bug real de auditoría (7-sep-2026, agente de revisión
    # independiente): la versión anterior solo mostraba ②c cuando el bloque
    # binning+óhmico tenía AL MENOS una fila, así que un proyecto con SOLO
    # pérdida óhmica DC activa (sin mismatch de fabricación) se quedaba sin
    # ninguna fila ②c en absoluto -- ni real ni informativa -- perdiendo el
    # disclaimer de PVsyst por completo. Ningún kWh salía mal (③ seguía
    # reconciliando exacto), pero la tabla dejaba de ser auditable en ese caso.
    _pct_fab_aplicado = res.get("pct_mismatch_fab_aplicado")
    _modo_ohmico_dc    = res.get("perdida_ohmica_dc_modo")
    _kwh_prev = round(E_dc_pre_binning, 0)

    if _pct_fab_aplicado is not None:
        _es_ultima_fab = _modo_ohmico_dc is None
        _kwh_fab = (
            round(res["E_dc_anual_kWh"], 0) if _es_ultima_fab
            else round(_kwh_prev - res.get("perdida_mismatch_fab_kWh", 0.0), 0)
        )
        filas.append({
            "Etapa": "②c Mismatch fabricación  (aplicado)",
            "kWh": _kwh_fab,
            "Δ kWh": round(_kwh_fab - _kwh_prev, 0),
            "Nota": (
                f"{_pct_fab_aplicado}% configurado en 🔀 Mismatch · PVsyst mostró +0,75% "
                "(ganancia) en 2 papers independientes como valor por defecto sin datos "
                "reales de binning -- compáralo contra tu propio reporte."
            ),
        })
        _kwh_prev = _kwh_fab
    else:
        filas.append({
            # Informativa, NUNCA aplicada al cálculo -- esta app no tiene datos
            # de binning/clasificación de fábrica del panel, así que no hay
            # ningún número propio que agregar aquí (mismo principio de nunca
            # inventar). +0,75% es el valor que PVsyst mostró, IDÉNTICO, en 2
            # papers reales e independientes (Kadir et al. 2023; Mohammadi &
            # Gezegin 2022) -- fuerte indicio de que es el DEFAULT del software
            # cuando el usuario no carga datos reales de binning, no una
            # medición específica de cada proyecto. Se muestra como referencia
            # para cuando compares contra tu propio reporte de PVsyst -- si el
            # tuyo también trae +0,75% aquí, confirma que es el default y no
            # algo que tu instalador midió. Δ kWh y kWh quedan iguales a la
            # fila anterior a propósito: cero efecto en el cálculo real.
            "Etapa":     "②c Módulo  (informativo — no aplicado por esta app)",
            "kWh":       round(_kwh_prev, 0),
            "Δ kWh":     0,
            "Nota":      ("PVsyst mostró +0,75% (ganancia) en 2 papers reales independientes -- "
                          "probable valor por defecto del software sin datos de binning propios. "
                          "Esta app no lo modela ni lo aplica; compáralo contra tu propio reporte."),
        })
        # _kwh_prev NO cambia -- fila informativa, Δ=0 a propósito.

    if _modo_ohmico_dc is not None:
        _fuente_dc = (
            "cálculo real del ⚡ Diagrama Unifilar, hora a hora con la corriente real"
            if _modo_ohmico_dc == "calculado" else
            "% manual configurado en 🔀 Mismatch"
        )
        # ②d, cuando aparece, siempre es la ÚLTIMA fila de este bloque --
        # se fuerza a E_dc_anual_kWh exacto (igual que ③ más abajo)
        # cualquier residuo de redondeo queda absorbido ahí, nunca
        # "perdido" ni inventado.
        _kwh_ohm = round(res["E_dc_anual_kWh"], 0)
        filas.append({
            "Etapa": "②d Pérdida óhmica DC  (cableado)",
            "kWh": _kwh_ohm,
            "Δ kWh": round(_kwh_ohm - _kwh_prev, 0),
            "Nota": f"Fuente: {_fuente_dc}",
        })
        _kwh_prev = _kwh_ohm

    filas += [
        {
            "Etapa":     "③ E_dc  (salida del array)",
            "kWh":       round(res["E_dc_anual_kWh"], 0),
            "Δ kWh":     0,
            "Nota":      "",
        },
        {
            "Etapa":     "④ Pérdida inversor (eficiencia)",
            "kWh":       round(res.get("E_ac_sin_recorte_kWh", res["E_ac_anual_kWh"]), 0),
            "Δ kWh":     round(delta_inv, 0),
            "Nota":      f"η_inv = {round(res.get('E_ac_sin_recorte_kWh', res['E_ac_anual_kWh']) / res['E_dc_anual_kWh'] * 100, 1) if res['E_dc_anual_kWh'] > 0 else '—'}%",
        },
        {
            "Etapa":     "④b Recorte inversor (Pnom, clipping)",
            "kWh":       round(res.get("E_ac_antes_ohmico_ac_kWh", res["E_ac_anual_kWh"]), 0),
            "Δ kWh":     round(-res.get("perdida_clipping_kWh", 0.0), 0),
            "Nota":      (
                f"{res.get('horas_con_clipping', 0):,} h/año recortadas"
                if res.get("perdida_clipping_kWh", 0.0) > 0
                else "Sin recorte -- DC/AC dentro del rango del inversor"
            ),
        },
    ]

    # ── ④c — Pérdida óhmica AC, REAL (7-sep-2026) ──────────────────────────────
    _modo_ohmico_ac = res.get("perdida_ohmica_ac_modo")
    if _modo_ohmico_ac is not None:
        _fuente_ac = (
            "cálculo real del ⚡ Diagrama Unifilar" if _modo_ohmico_ac == "calculado"
            else "% manual configurado en 🔀 Mismatch"
        )
        _kwh_prev_ac = round(res.get("E_ac_antes_ohmico_ac_kWh", res["E_ac_anual_kWh"]), 0)
        _kwh_ac_final = round(res["E_ac_anual_kWh"], 0)
        filas.append({
            "Etapa":     "④c Pérdida óhmica AC  (cableado)",
            "kWh":       _kwh_ac_final,
            "Δ kWh":     round(_kwh_ac_final - _kwh_prev_ac, 0),
            "Nota":      f"Fuente: {_fuente_ac}",
        })

    filas.append({
        "Etapa":     "⑤ E_ac  (energía a la red / edificio)",
        "kWh":       round(res["E_ac_anual_kWh"], 0),
        "Δ kWh":     0,
        "Nota":      "",
    })
    df = pd.DataFrame(filas)
    df["% de E_ref"] = (df["Δ kWh"].abs() / ref_dc * 100).round(2)
    return df
